﻿namespace OnlineShop.Models
{
    public abstract class ComponentBase
    {
    }
}