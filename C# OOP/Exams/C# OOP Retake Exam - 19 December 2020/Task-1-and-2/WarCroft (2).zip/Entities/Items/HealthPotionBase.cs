﻿namespace WarCroft.Entities.Items
{
    public class HealthPotionBase
    {
    }
}