﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WarCroft.Entities.Items
{
    class FirePotion
    {
    }
}
