﻿using System;
using System.Collections.Generic;
using System.Text;
using _07.MilitaryElite.Enums;

namespace _07.MilitaryElite.Contracts
{
    public interface ISpecialisedSoldier
    {
        string Corps { get; }

    }
}
