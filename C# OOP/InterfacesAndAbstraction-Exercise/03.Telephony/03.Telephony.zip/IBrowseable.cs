﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Telephony
{
    interface IBrowseable
    {
        string Browse(string url);
    }
}
