﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var tires = new Tire[4]
            {
                new Tire(1, 2.2),
                new Tire(1, 2.1),
                new Tire(2, 1.8),
                new Tire(2, 1.9),
            };

            var engine = new Engine(170, 2000);

            var car = new Car("BMW", "320", 2009, 55, 9, engine, tires);

            Console.WriteLine(car.WhoAmI());
        }
    }
}
