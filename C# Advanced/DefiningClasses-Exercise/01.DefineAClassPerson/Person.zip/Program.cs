﻿using System;

namespace DefiningClasses
{
    public class StartUp 
    { 
        static void Main(string[] args)
        {
            string name = Console.ReadLine();
            int age = int.Parse(Console.ReadLine());

            Console.WriteLine($"Name is: {name}, {age} years old.");
        }
    }
}
